<?php
//This is the config.php file

// Specify your login credentials
$username   = "sandbox";
$apikey     = "6fa096242bba3e97dd55e88929f4ed5b5557f01df1f8d1900d359735d00b1534";

?>